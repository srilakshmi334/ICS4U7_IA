// Import the following packages:
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * The following super class is for the general user of the program
 * @author Sri
 *
 */
public abstract class User extends GUIComponents {
	
	// User info
//	static String username;
//	static String password;
//	static JFrame f = ChemApp.frame;
	
//	public static ChemApp button = new ChemApp();
//	public static ChemApp label = new ChemApp();
//	public static ChemApp field = new ChemApp();
//	public static ChemApp field2 = new ChemApp();
//	public static ChemApp getField = new ChemApp();
//	public static ChemApp chkBox = new ChemApp();
//	public static ChemApp sChkBox = new ChemApp();
	
	// For displaySignUp()
//	static JTextField userInput = new JTextField();
//	static JTextField pwdInput = new JTextField();
//	static JLabel infoStatus = new JLabel("");
	
	// For displayLogin()
//	static HashMap<String, String> info = new HashMap<String, String>(); // stores login info
//	static HashMap<String, String> info2 = new HashMap<String, String>();
	
//	static String readLine;
//	static String accntFile = "./accounts.txt";
//	static String accntFile2 = "./accounts2.txt";
	
//	static String typeOfUser;
//	static String user;
//	static String pwd;
//	
//	static String user2;
//	static String pwd2;
	
//	static JTextField userType = new JTextField();
//	static JTextField userInfo = new JTextField();
//	static JTextField pwdInfo = new JTextField();
	
//	static JButton signup = new JButton("complete sign-up");
//	static JButton enter = new JButton("enter");
	
//	static Student s = new Student(GUIComponents.user, GUIComponents.pwd);
//	static Teacher t = new Teacher(GUIComponents.user, GUIComponents.pwd);
	
//	static Student s;
//	static Teacher t;
	
//	static JTextField sNum = new JTextField();
//	static JTextField uEmail = new JTextField();
	
//	static boolean enterSPlannerPage = false;
	
	/**
	 * The following constructor is for creating the User object
	 * @param username
	 * @param pwd
	 */
	public User(String username, String pwd) {
		user = username;
		pwd = pwd;
	}
//	
//	/**
//	 * The following getter method gets the user's name
//	 * @return username
//	 */
//	public String getUsername() {
//		return username;
//	}
//	
//	/**
//	 * The following getter method gets the user's pwd
//	 * @return pwd
//	 */
//	public String getPwd() {
//		return password;
//	}
	
//	public void printUserName() {
//		String user = userInfo.getText();
//		label.addLabel("hello, " + user, 20, 20, 200, 30, Font.PLAIN, 20, 255, 255, 255, f);
//	}
	
	/**
	 * The following method displays the user's info on the planner page
	 */
	public void printUserInfo() {
		
		// Page header
		label.addLabel("your planner", 240, 50, 240, 45, Font.BOLD, 35, 255, 255, 255, f);
		
		// Greet the user
		String user = userInfo.getText();
		label.addLabel("hello, " + user, 20, 20, 200, 30, Font.PLAIN, 20, 255, 255, 255, f);
		
		// Check the type of user that is using the program, display page accordingly
		typeOfUser = userType.getText();
		if (typeOfUser.equalsIgnoreCase("s") || typeOfUser.equalsIgnoreCase("student") || 
				AppMenu.sPress == true) {
			label.addLabel("student #: ", 20, 130, 200, 30, Font.PLAIN, 22, 51, 55, 138, f);
			label.addLabel("student email: ", 20, 180, 200, 30, Font.PLAIN, 22, 51, 55, 138, f);
			
			sNum.setBounds(130, 135, 200, 20);
			sNum.setFont(new Font("Ink Free", Font.PLAIN, 15));
			f.add(sNum);
			
			uEmail.setBounds(165, 185, 200, 20);
			uEmail.setFont(new Font("Ink Free", Font.PLAIN, 15));
			f.add(uEmail);
		}
		
//		else if (User.typeOfUser.equalsIgnoreCase("t") || User.typeOfUser.equalsIgnoreCase("teacher") ||
//					AppMenu.sPress == false) {
////			label.addLabel("teacher #: ", 20, 130, 200, 30, Font.PLAIN, 22, 51, 55, 138, f);
//			label.addLabel("teacher email: ", 20, 130, 200, 30, Font.PLAIN, 22, 51, 55, 138, f);
//			
//			uEmail.setBounds(165, 135, 200, 20);
//			uEmail.setFont(new Font("Ink Free", Font.PLAIN, 15));
//			f.add(uEmail);
//		}
		
//		sNum.setBounds(130, 135, 200, 20);
//		sNum.setFont(new Font("Ink Free", Font.PLAIN, 15));
//		f.add(sNum);
	}
	
	public static void checkUserType() {
		
		// Set background of frame
		f.getContentPane().setBackground(new Color(119, 158, 186));

		// Create login header/sub-header
		label.addLabel("wait, confirm your identity", 130, 30, 480, 45, Font.BOLD, 35, 255, 255, 255, f);
		label.addLabel("enter student or teacher", 220, 90, 330, 30, Font.PLAIN, 20, 245, 240, 228, f);
	
		label.addLabel("user type", 180, 160, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
		label.addLabel("type s or t", 180, 185, 110, 30, Font.PLAIN, 14, 51, 55, 138, f);
		
		userType.setBounds(290, 165, 200, 20);
		userType.setFont(new Font("Ink Free", Font.PLAIN, 15));
		f.add(userType);
		
		button.addButton("confirm", 280, 250, 110, 40, 20, f);
	}
	
//	/**
//	 * The following method allows the user to enter their sign-up info
//	 */
	public static void displaySignUp() {

		// Set background of frame
		f.getContentPane().setBackground(new Color(119, 158, 186));

		// Create sign-up page header
		label.addLabel("sign-up", 280, 30, 120, 45, Font.BOLD, 35, 255, 255, 255, f);
		label.addLabel("create your account here!", 235, 90, 330, 30, Font.PLAIN, 20, 245, 240, 228, f);

		// Create JLabels/JFields for user to enter info
		label.addLabel("username", 180, 160, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
		label.addLabel("password", 180, 210, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
		label.addLabel("min 8 characters", 180, 240, 180, 20, Font.PLAIN, 14, 51, 55, 138, f);

		userInput.setBounds(290, 165, 200, 20);
		userInput.setFont(new Font("Ink Free", Font.PLAIN, 15));

		pwdInput.setBounds(290, 215, 200, 20);
		pwdInput.setFont(new Font("Ink Free", Font.PLAIN, 15));

		f.add(userInput);
		f.add(pwdInput);

		// Customize sign-up button
//		JButton signup = new JButton("complete sign-up");
		signup.setBounds(225, 290, 230, 40);
		signup.setFont(new Font("Ink Free", Font.BOLD, 25));
		signup.setForeground(new Color(44, 79, 110));
		signup.setBackground(new Color(186, 210, 232));

		// Add sign-up button to frame
		f.add(signup);

		// Create back to sign-up button
		button.addButton("back to sign-up menu", 440, 455, 230, 35, 20, f);

	}
	
//	/**
//	 * The following method is for the user to login to the application
//	 */
	public static void displayLogin() {

		// Set background of frame
		f.getContentPane().setBackground(new Color(119, 158, 186));

		// Create login header/sub-header
		label.addLabel("login", 300, 30, 120, 45, Font.BOLD, 35, 255, 255, 255, f);
		label.addLabel("enter the appropriate info", 220, 90, 330, 30, Font.PLAIN, 20, 245, 240, 228, f);

		// Create JLabels/JFields for user to enter info
//		label.addLabel("user type", 180, 160, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
//		label.addLabel("type s or t", 180, 180, 110, 30, Font.PLAIN, 14, 51, 55, 138, f);
		label.addLabel("username", 180, 160, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
		label.addLabel("password", 180, 210, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
		
//		userType.setBounds(290, 165, 200, 20);
//		userType.setFont(new Font("Ink Free", Font.PLAIN, 15));
//		f.add(userType);

		userInfo.setBounds(290, 165, 200, 20);
		userInfo.setFont(new Font("Ink Free", Font.PLAIN, 15));
		f.add(userInfo);

		pwdInfo.setBounds(290, 215, 200, 20);
		pwdInfo.setFont(new Font("Ink Free", Font.PLAIN, 15));
		f.add(pwdInfo);

		// Create enter button
//		JButton enter = new JButton("enter");
		enter.setBounds(280, 270, 110, 40);
		enter.setFont(new Font("Ink Free", Font.BOLD, 25));
		enter.setForeground(new Color(44, 79, 110));
		enter.setBackground(new Color(186, 210, 232));

		f.add(enter);

		// Create back to sign-up button
		button.addButton("back to sign-up menu", 440, 455, 230, 35, 20, f);

		// Store login information
		info = new HashMap<>();
		info2 = new HashMap<>();
	}
	
	public abstract void displaySignUpPage();
	public abstract void displayLoginPage();
	public abstract void displayPlannerPage();
	
}
