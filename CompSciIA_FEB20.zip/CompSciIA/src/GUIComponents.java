// Import the following packages:
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * The following class contains all the static variables that are accessed in the
 * User, Student, & Teacher classes
 * @author Sri
 *
 */
public class GUIComponents {

	static JFrame f = ChemApp.frame;
	
	// Objects to link classes
	static Student s = new Student(GUIComponents.user, GUIComponents.pwd);
	static Teacher t = new Teacher(GUIComponents.user, GUIComponents.pwd);
	
	public static ChemApp button = new ChemApp();
	public static ChemApp label = new ChemApp();
	public static ChemApp field = new ChemApp();
	public static ChemApp field2 = new ChemApp();
	public static ChemApp getField = new ChemApp();
	public static ChemApp chkBox = new ChemApp();
	
	static String readLine;
	static String accntFile = "./accounts.txt";
//	static String accntFile2 = "./accounts2.txt";
	
	static String typeOfUser;
	static String user;
	static String pwd;
	
//	static String user2;
//	static String pwd2;
	
	// For displaySignUp()
	static JTextField userInput = new JTextField();
	static JTextField pwdInput = new JTextField();
	static JLabel infoStatus = new JLabel("");
	
	// For displayLogin()
	static HashMap<String, String> info = new HashMap<String, String>(); // stores login info
	static HashMap<String, String> info2 = new HashMap<String, String>();
	
	// Student & Teacher classes
	static JTextField userType = new JTextField();
	static JTextField userInfo = new JTextField();
	static JTextField pwdInfo = new JTextField();

	static JButton signup = new JButton("complete sign-up");
	static JButton enter = new JButton("enter");
	
	static JTextField sNum = new JTextField();
	static JTextField uEmail = new JTextField();
	
	static boolean enterSPlannerPage = false;
	
}
