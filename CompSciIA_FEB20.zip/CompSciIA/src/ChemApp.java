// ICS4U7 IA Project: Chem IA Planner
// Author: Sri
// Date: 27/10/2023

// Import the following packages:
import java.io.*;
import java.util.*;
import java.util.Timer;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * The following class runs the main method of the application
 * @author Sri
 *
 */
public class ChemApp extends JFrame implements ActionListener {

	// Create a JFrame
	public static JFrame frame = new JFrame("don't bomb it");

	// Create instance variables to call addButton() and addLabel() method
	public static ChemApp button = new ChemApp();
	public static ChemApp label = new ChemApp();

	static Student s = new Student(GUIComponents.user, GUIComponents.pwd);
	static Teacher t = new Teacher(GUIComponents.user, GUIComponents.pwd);
	
	static String a;
	
	static JTextField stf;
	static ArrayList<JTextField> jtf = new ArrayList<>();
	static ArrayList<String> ss = new ArrayList<>();

	/**
	 * The following is a constructor for the main app's frame and background
	 */
	public ChemApp() {

		// Set the current size and background of the frame
		frame.setSize(700, 550);
		frame.getContentPane().setBackground(new Color(119, 158, 186));
	}

	/**
	 * The following main method runs the program and displays all the components on the frame
	 * @param args
	 */
	public static void main(String[] args) {

		// Call welcome page method
		displayWelcomePage();

		// Display the components on the JFrame
		frame.setLayout(null);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	/**
	 * The following method displays the welcome page of the application
	 */
	public static void displayWelcomePage() {

		// Set current design of JFrame
		frame.setSize(700, 550);
		frame.getContentPane().setBackground(new Color(119, 158, 186));

		// Initialize label titles for the welcome page
		String header = "don't bomb it";
		String subHeader = "the chem IA planner you didn't know you needed";

		// Create JLabels for the welcome page
		label.addLabel(header, 135, 100, 600, 80, Font.BOLD, 67, 255, 255, 255, frame); // header
		label.addLabel(subHeader, 50, 200, 630, 40, Font.PLAIN, 28, 51, 55, 138, frame); // sub-header

		// Create JButtons for about and main menu pages
		button.addButton("about", 150, 270, 145, 45, 30, frame); // about
		button.addButton("main menu", 325, 270, 190, 45, 30, frame); // main menu

	}

	/**
	 * The following method displays the about page of the application
	 */
	public static void displayAbout() {

		// Set background of frame
		frame.getContentPane().setBackground(new Color(119, 158, 186));

		// Create a JLabel header for the about page
		label.addLabel("your one stop lab planner", 150, 23, 400, 40, Font.BOLD, 35, 255, 255, 255, frame);

		// Run about program info through a text file and display w/ JTextArea
		String file = "./aboutDBI.txt";
		String line;

		// Set design of about info area
		JTextArea aboutApp = new JTextArea();
		aboutApp.setBounds(50, 80, 600, 380);
		aboutApp.setFont(new Font("Ink Free", Font.BOLD, 16));
		aboutApp.setForeground(new Color(19, 52, 92));
		aboutApp.setOpaque(false); // make JTextArea transparent

		aboutApp.setEditable(false);
		aboutApp.setLineWrap(true);
		aboutApp.setWrapStyleWord(true);

		// Add about JTextArea to the frame
		frame.add(aboutApp);

		// Try reading in the about file and add each line to the JTextArea
		try {
			BufferedReader readInLine = new BufferedReader(new FileReader(file));

			while((line = readInLine.readLine()) != null) {
				aboutApp.read(readInLine, "aboutApp");
			}
		}

		// If file doesn't exist, catch exception and print an error message to the console
		catch (IOException iox) {
			System.out.println("Problem reading " + file);
		}

		// Create copyright label
		String copyright = "Copyright don't bomb it 2023. All Rights Reserved. CompSciIA2024";
		label.addLabel(copyright, 120, 480, 430, 20, Font.PLAIN, 14, 255, 255, 255, frame);

		// Create back button
		button.addButton("back", 580, 445, 80, 35, 20, frame);
		
	}

	/**
	 * The following method is to add new buttons to the frame
	 * @param label
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param fontSize
	 * @param frame
	 */
	public static void addButton(String n, int x, int y, int w, int h, int fontSize, JFrame frame) {

		// Set design of JButtons
		JButton b = new JButton(n);
		b.setBounds(x, y, w, h);
		b.setFont(new Font("Ink Free", Font.BOLD, fontSize));
		b.setForeground(new Color(44, 79, 110));
		b.setBackground(new Color(186, 210, 232));

		frame.add(b); // add JButton to the frame

		// Add an ActionListener for the buttons
		b.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// Clear and repaint the frame
				frame.getContentPane().removeAll();
				frame.repaint();

				// Check which button is being called before completing the actions
				if (n == "about") {	
					displayAbout();
				}

				else if (n == "back") {
					displayWelcomePage();
				}

				else if (n == "main menu") {
					AppMenu.displayMenu();
				}
				
				else if (n == "login") {
					User.checkUserType();
					GUIComponents.infoStatus.setText("");
				}
				
				else if (n == "confirm") {
					GUIComponents.typeOfUser = GUIComponents.userType.getText();
					if (GUIComponents.typeOfUser.equalsIgnoreCase("s") || GUIComponents.typeOfUser.equalsIgnoreCase("student")) {
						s.displayLoginPage();
					}
					else if (GUIComponents.typeOfUser.equalsIgnoreCase("t") || GUIComponents.typeOfUser.equalsIgnoreCase("teacher")) {
						t.displayLoginPage();
					}
					else {
						User.checkUserType();
						GUIComponents.infoStatus.setText("oops, wrong user. try again!");
						GUIComponents.infoStatus.setBounds(225, 320, 420, 40);
						GUIComponents.infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
						GUIComponents.infoStatus.setForeground(new Color(245, 240, 228));

						GUIComponents.f.add(GUIComponents.infoStatus);
					}
				}
				
				else if (n == "back to sign-up menu") {
					GUIComponents.infoStatus.setText("");
					GUIComponents.userType.setText("");
					frame.getContentPane().remove(GUIComponents.infoStatus);
					AppMenu.displayMenu();
				}
				
				else if (n == "back to planner") {
					frame.getContentPane().removeAll();
					frame.repaint();
					GUIComponents.typeOfUser = GUIComponents.userType.getText();
					if (GUIComponents.typeOfUser.equalsIgnoreCase("t") || GUIComponents.typeOfUser.equalsIgnoreCase("teacher") || AppMenu.sPress == false) {
						t.displayPlannerPage();
					}
					Teacher.stName.setText("");
					Teacher.stEmail.setText("");

				}
				
				else if (n == "logout") {
					label.addLabel("you've signed out successfully, see you later!", 105, 230, 470, 30, Font.PLAIN, 25, 51, 55, 138, GUIComponents.f);
//					button.addButton("back to main page", 160, 280, 190, 40, 23, User.f);
				}
				
//				else if (n == "back to main page") {
//					displayWelcomePage();
//					User.userType.setText("");
//					User.userInput.setText("");
//					User.pwdInput.setText("");
//					User.userInfo.setText("");
//					User.pwdInfo.setText("");
//				}

//				else if (n == "back to sign-up menu") {
//					frame.getContentPane().removeAll();
//					AppMenu.displayMenu();
//					frame.repaint();
//				}

			}
		});

	}

	/**
	 * The following method is to add new labels to the frame
	 * @param n
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param fontType
	 * @param fontSize
	 * @param frame
	 */
	public static void addLabel(String n, int x, int y, int w, int h, int fontType, int fontSize, int r, int g, int b, JFrame frame) {

		// Set design of JLabels
		JLabel l = new JLabel(n);
		l.setBounds(x, y, w, h);
		l.setFont(new Font("Ink Free", fontType, fontSize));
		l.setForeground(new Color(r, g, b));

		frame.add(l); // add JLabel to the frame
	}
	
	/**
	 * The following method is for adding JTextFields with a JScrollPane (for Student class)
	 * @param sp
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param frame
	 */
	public static void addTextField(JScrollPane sp, int x, int y, int w, int h, JFrame frame) {

		// Set design of JTextFields
//		JTextField k = new JTextField();	
		
		stf = new JTextField();
		stf.setFont(new Font("Ink Free", Font.PLAIN, 15));
		
//		tf = new JTextField();
//		tf.setFont(new Font("Ink Free", Font.PLAIN, 15));

		// Set design of JScrollPane
		sp = new JScrollPane(stf, JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		sp.setBounds(x, y, w, h);
		
		frame.add(sp); // add JScrollPane to the frame
	
		jtf.add(stf);
		
	}
	
	public void addTextField(String m, String n) {
//		JTextField b = new JTextField();
		
//		f = new JTextField();
//		f.setFont(new Font("Ink Free", Font.PLAIN, 15));
		
		if (Student.saveInfoPress == true) {
			try {
//				n = stf.getText();
//				ss.add(n);
//				p = f.getText();
//				n = p;
//				ArrayList<JTextField> k = new ArrayList<>();
				for (int i = 0; i < jtf.size(); i++) {
					n = jtf.get(i).getText();
					Student.fw = new FileWriter(Student.IAfile, true);
					Student.fw.write("\n" + m + n);
//					stf.setEnabled(false);
				}
//				System.out.println(n);
//				for (int i = 0; i < ss.size(); i++) {
////					n = ss.get(i);
////					System.out.println(ss.get(i));
//					Student.fw = new FileWriter(Student.IAfile, true);
//					Student.fw.write("\n" + m + ss.get(i));
//				}
//				n = stf.getText();
//				Student.fw = new FileWriter(Student.IAfile, true);
//				Student.fw.write("\n" + m + n);
//				n = "";
//				stf.setEnabled(false);
				
				Student.fw.close();
//				stf.setText("");
//				n = "";
			}
			catch(IOException iox) {
				System.out.println("Problem writing " + Student.IAfile);
			}
		}
	}
	
	
	
	/**
	 * The following method adds checkboxes to the frame (for inventory list/teacher checklist)
	 * @param n
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param p
	 */
	public static void addCheckBox(String n, int x, int y, int w, int h, JPanel p, ArrayList<String> s) {
		
		JCheckBox cb = new JCheckBox(n);
		cb.setBounds(x, y, w, h);
		cb.setFont(new Font("Ink Free", Font.PLAIN, 19));
		cb.setBackground(null);
		
		p.add(cb);
		
		for (int i = 0; i < s.size(); i++) {
			s.add(i, s.get(i));
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}
