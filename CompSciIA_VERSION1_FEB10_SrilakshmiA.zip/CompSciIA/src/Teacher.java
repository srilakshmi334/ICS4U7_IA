// Import the following packages:
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * The following sub-class is for the teacher profile
 * @author Sri
 *
 */
public class Teacher extends User {
	
	static JTextField stName = new JTextField();
	static JTextField stEmail = new JTextField();
	static JButton viewIA = new JButton("view IA");
	
	static JFrame checkListF = new JFrame("checklist");

	public Teacher(String username, String pwd) {
		super(username, pwd);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void displayPlannerPage() {
		// TODO Auto-generated method stub
		
//		if (User.typeOfUser.equalsIgnoreCase("t") || User.typeOfUser.equalsIgnoreCase("teacher")) {
		
		// Add header and user info
		printUserInfo();

		label.addLabel("welcome, this is your page to review your students' IAs", 70, 130, 520, 30, Font.PLAIN, 22, 51, 55, 138, f);
		label.addLabel("enter student username and email to view", 165, 180, 330, 20, Font.PLAIN, 18, 245, 240, 228, f);
	
		// Add fields for teacher to enter student info to check IA planning progress
		label.addLabel("student name:", 160, 230, 200, 30, Font.PLAIN, 20, 245, 241, 240, f);
		stName.setBounds(295, 235, 200, 20);
		stName.setFont(new Font("Ink Free", Font.PLAIN, 15));
		f.add(stName);
		
		label.addLabel("AND", 320, 280, 50, 30, Font.PLAIN, 21, 51, 55, 138, f);
		
		label.addLabel("student email:", 160, 320, 200, 30, Font.PLAIN, 20, 245, 241, 240, f);
		stEmail.setBounds(295, 325, 200, 20);
		stEmail.setFont(new Font("Ink Free", Font.PLAIN, 15));
		f.add(stEmail);
		
		// Create button to show teacher, student's IA planning
		viewIA.setBounds(260, 380, 140, 45);
		viewIA.setFont(new Font("Ink Free", Font.BOLD, 23));
		viewIA.setForeground(new Color(51, 55, 138));
		viewIA.setBackground(new Color(200, 195, 212));
		f.add(viewIA);
		
		button.addButton("logout", 510, 440, 140, 40, 22, f);
		
		viewIA.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
//				if (stEmail.getText() == )
//				
//				if (stName.getText() == uEmail.getText() || stNumber.getText() == sNum.getText()) {
//					System.out.println("2");
//				}
				
				String n = stName.getText();
				Student.IAfile = n + "IAinfo.txt";
				
//				String file = Student.IAfile;
//				System.out.println(file);
				String l;
				boolean found = false;
				
				if (found == false) {
					label.addLabel("sorry, wrong user or email, please try again", 155, 400, 400, 20, Font.PLAIN, 20, 245, 240, 228, f);
				}
				
//				if (l.equals(stEmail.getText())) {
//					System.out.println("2");
//				}
				
				try {
					BufferedReader br = new BufferedReader(new FileReader(Student.IAfile));
					
					while ((l = br.readLine()) != null) {
						String check = stEmail.getText();
						if (l.contains(check)) {
							found = true;
						}
//						else {
//							found = false;
//						}
					}
				}
				
				catch(IOException iox) {
					System.out.println("Problem reading " + Student.IAfile);
				}
				
				if (found == true) {
					f.getContentPane().removeAll();
					f.repaint();
					f.setSize(700, 580);
					
					label.addLabel(n + "'s " + "IA", 270, 30, 220, 45, Font.BOLD, 35, 255, 255, 255, f);
					JTextArea a = new JTextArea(5, 20);
					a.setFont(new Font("Ink Free", Font.PLAIN, 18));
					a.setForeground(new Color(51, 55, 138));
					
					a.setEditable(false);
					a.setLineWrap(true);
					a.setWrapStyleWord(true);
					a.setLayout(new BoxLayout(a, BoxLayout.PAGE_AXIS));
					
					JScrollPane aInfo = new JScrollPane(a, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
					aInfo.setBounds(32, 90, 620, 390);
					aInfo.setBackground(new Color(247, 246, 235));
					
					f.add(aInfo);
					
					String expLine;
					
					try {
						BufferedReader readExp = new BufferedReader(new FileReader(Student.IAfile));
						while ((expLine = readExp.readLine()) != null) {
							a.read(readExp, "a");
						}
					}
					catch(IOException iox) {
						System.out.println("Problem reading " + Student.IAfile);
					}
					
//					f.revalidate();
				}
				if (found == false) {
					label.addLabel("sorry, wrong user or email, please try again", 155, 400, 400, 20, Font.PLAIN, 20, 245, 240, 228, f);
				}
				
				displayCheckList();
			}
			
		});
		
		//	}
	}
	
	
	public void displayCheckList() {
		
		JButton checkList = new JButton("IA checklist");
		checkList.setBounds(30, 490, 180, 40);
		checkList.setFont(new Font("Ink Free", Font.BOLD, 22));
		checkList.setBackground(new Color(200, 195, 212));
		checkList.setForeground(new Color(51, 55, 138));
		f.add(checkList);
		
		button.addButton("back to planner", 452, 490, 200, 40, 22, f);
		
		checkList.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				checkListF.setLayout(null);
				checkListF.setVisible(true);
				checkListF.setResizable(false);
				checkListF.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				
				checkListF.setSize(350, 450);
				checkListF.getContentPane().setBackground(new Color(119, 158, 186));
				
				label.addLabel("check off all that apply: ", 50, 30, 230, 30, Font.BOLD, 20, 245, 240, 228, checkListF);
				
				JPanel clist = new JPanel();
				clist.setBounds(18, 70, 300, 250);
				clist.setBackground(new Color(167, 178, 194));
				clist.setBorder(null);
				clist.setLayout(new BoxLayout(clist, BoxLayout.PAGE_AXIS));
				
				checkListF.add(clist);
				
				String[] arr = {"topic", "research question", "hypothesis", "materials", "procedure"};
				
				for (int i = 0; i < arr.length; i++) {
					chkBox.addCheckBox(arr[i], 0, 0, 0, 0, clist);
				}
				
				
			}
			
		});
		
	}

	@Override
	public void displaySignUpPage() {
		// TODO Auto-generated method stub
		displaySignUp();
		
		signup.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// Get username and password
				String userField = userInput.getText();
				String pwdField = pwdInput.getText();

				// Repaint the JFrame and add a JLabel on the button click
				f.getContentPane();
				f.repaint();

				// Validate the user's info

				if (userField.length() < 1 || pwdField.length() < 8) {

					// Inform the user that their information is incorrect
					infoStatus.setText("seems like your info is incorrect, try again!");
					infoStatus.setBounds(160, 350, 420, 40);
					infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
					infoStatus.setForeground(new Color(245, 240, 228));

					f.add(infoStatus);
				}

				else {

					// If correct, put info in the hash map
					info.put(userField, pwdField);


					//	if (e.getSource() == student) {

					// Add info to a text file
					try {

						// Try writing user's info into the text file
						BufferedWriter bw = new BufferedWriter(new FileWriter(accntFile, true));
						bw.write(userField + " " + pwdField + "\n");

						bw.close(); // close the writer after info is added

						// Inform the user that they can now login
						infoStatus.setText("you're ready to sign-up!");
						infoStatus.setBounds(160, 370, 200, 40);
						infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
						infoStatus.setForeground(new Color(245, 240, 228));

						f.add(infoStatus);

						// Direct user to login
						JButton reLogin = new JButton("login here");
						reLogin.setBounds(380, 370, 150, 40);
						reLogin.setFont(new Font("Ink Free", Font.BOLD, 25));
						reLogin.setForeground(new Color(44, 79, 110));
						reLogin.setBackground(new Color(213, 218, 237));

						reLogin.addActionListener(new ActionListener() {

							@Override
							public void actionPerformed(ActionEvent e) {
								// TODO Auto-generated method stub

								// Clear and repaint the frame
								f.getContentPane().removeAll();
								f.repaint();

								// Link to the login page
								t.displayLoginPage();
							}

						});

						// Add re-login button to frame
						f.add(reLogin);

					}

					// Else, catch the exception
					catch(IOException iox) {
						System.out.println("Problem writing " + accntFile);
					}
				}

			}

		});
		
	}

	@Override
	public void displayLoginPage() {
		// TODO Auto-generated method stub
		displayLogin();
	
		try {
			BufferedReader read = new BufferedReader(new FileReader(accntFile));
			String username = "";
			String password = "";
			String[] accountInfo;

			while ((readLine = read.readLine()) != null) {
				accountInfo = readLine.split(" "); // split the info in the array w/ a space

				// Store username and password info in the array
				username = accountInfo[0];
				password = accountInfo[1];

				// Add account information to hash map
				info.put(username, password);
			}

		}

		// If the file doesn't exist, catch the exception and print an error message
		catch (IOException iox) {
			System.out.println("Problem reading " + accntFile);
		}


		// Create an ActionListener for when the user hits the enter button to login
		enter.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// Inform user of their login status
				infoStatus.setBounds(180, 320, 400, 40);
				infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
				infoStatus.setForeground(new Color(245, 240, 228));

				// When the user hits enter, get the text in the username and password fields
				if (e.getSource() == enter) {
//					typeOfUser = userType.getText();
					user = userInfo.getText();
					pwd = pwdInfo.getText();

					// If the user has entered the correct username and password,
					// direct them to their profile
//					if (typeOfUser.equals("t")) {
					if (info.containsKey(user)) {
						if (info.get(user).equals(pwd)) {

							// Clear and re-colour the frame
							f.getContentPane().removeAll();
							f.setBackground(new Color(119, 158, 186));

							// Link to user's profile page
							// Student s = new Student(user, pwd);
//							printUserInfo();
							t.displayPlannerPage();

						}

						// If the user has the correct username but wrong password,
						// display an error message saying the password is wrong
						else {
							infoStatus.setBounds(220, 320, 400, 40);
							infoStatus.setText("wrong password, try again!");
							f.add(infoStatus);
							userInfo.setText("");
							pwdInfo.setText("");

							f.repaint();
//							f.remove(infoStatus);
//							f.getContentPane().repaint();
						}
					}

					// If the user does not have any correct info, display an error message
					// saying that the account does not exist
					else {
						infoStatus.setText("this account doesn't exist, try again!");
						f.add(infoStatus);
						userInfo.setText("");
						pwdInfo.setText("");

						f.repaint();
						f.revalidate();
						
						// If the user accidentally enters as a teacher and then changes to a
						// student, remove the label to fix bug
						if (enterSPlannerPage == true) {
							f.remove(infoStatus); // check if boolean is true, then remove the label
						}
					}	

				}

			}

		});
		
	}

}
