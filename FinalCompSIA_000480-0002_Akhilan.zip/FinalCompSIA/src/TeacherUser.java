/**
 * The following sub-class for a teacher user inherits the super class GeneralUser
 * @author Sri
 *
 */
public class TeacherUser extends GeneralUser {

	public TeacherUser(String username, String password) {
		super(username, password);
		// TODO Auto-generated constructor stub
	}

}
