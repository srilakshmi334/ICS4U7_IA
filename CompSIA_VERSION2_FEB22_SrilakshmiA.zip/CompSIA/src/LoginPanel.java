// Import the following packages:
import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class LoginPanel extends JPanel {
	
	private JLabel loginHeader, instrInfo, userLbl, pwdLbl, infoStatus;
	private JTextField userInfo, pwdInfo;
	private JButton enterBtn, backToSignUpBtn;
	
	public LoginPanel() {
		
		this.setLayout(null);
		this.setBackground(new Color(119, 158, 186));
		
		loginHeader = GUIComp.setLabel("login", 300, 30, 120, 45, Font.BOLD, 35, 255, 255, 255);
		this.add(loginHeader);
		
		instrInfo = GUIComp.setLabel("enter the appropriate info", 220, 90, 330, 30, Font.PLAIN, 20, 245, 240, 228);
		this.add(instrInfo);
		
		userLbl = GUIComp.setLabel("username", 180, 160, 110, 30, Font.PLAIN, 20, 51, 55, 138);
		this.add(userLbl);
		
		pwdLbl= GUIComp.setLabel("password", 180, 210, 110, 30, Font.PLAIN, 20, 51, 55, 138);
		this.add(pwdLbl);
		
		userInfo = new JTextField();
		userInfo.setBounds(290, 165, 200, 20);
		userInfo.setFont(new Font("Ink Free", Font.PLAIN, 15));
		
		pwdInfo = new JTextField();
		pwdInfo.setBounds(290, 215, 200, 20);
		pwdInfo.setFont(new Font("Ink Free", Font.PLAIN, 15));
		
		this.add(userInfo);
		this.add(pwdInfo);
		
		enterBtn = new JButton("enter");
		enterBtn.setBounds(280, 270, 110, 40);
		enterBtn.setFont(new Font("Ink Free", Font.BOLD, 25));
		enterBtn.setForeground(new Color(44, 79, 110));
		enterBtn.setBackground(new Color(186, 210, 232));
		this.add(enterBtn);
		
		backToSignUpBtn = GUIComp.setButton("back to sign-up menu", 440, 455, 230, 35, 20);
		this.add(backToSignUpBtn);
		
		backToSignUpBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				infoStatus.setText("");
				ChemPlanApp.cl.show(ChemPlanApp.c, "appMenuPage");
			}
			
		});
	}
}
