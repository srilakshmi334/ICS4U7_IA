// Import the following packages:
import java.awt.*;
import javax.swing.*;

public class GUIComp {

	/**
	 * The following method creates JLabels
	 * @param n
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param fontType
	 * @param fontSize
	 * @param r
	 * @param g
	 * @param b
	 * @return JLabel
	 */
	public static JLabel setLabel(String n, int x, int y, int w, int h, int fontType, int fontSize, int r, int g, int b) {

		// Set design of JLabels
		JLabel l = new JLabel(n);
		l.setBounds(x, y, w, h);
		l.setFont(new Font("Ink Free", fontType, fontSize));
		l.setForeground(new Color(r, g, b));

		return l; // add JLabel to the frame
	}
	
	/**
	 * The following method creates JButtons
	 * @param n
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param fontSize
	 * @param frame
	 * @return JButton
	 */
	public static JButton setButton(String n, int x, int y, int w, int h, int fontSize) {

		// Set design of JButtons
		JButton b = new JButton(n);
		b.setBounds(x, y, w, h);
		b.setFont(new Font("Ink Free", Font.BOLD, fontSize));
		b.setForeground(new Color(44, 79, 110));
		b.setBackground(new Color(186, 210, 232));
		
		return b;
	}
	
	/**
	 * The following method creates JButtons with images
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param r
	 * @param g
	 * @param bl
	 * @param ic
	 * @return JButton
	 */
	public static JButton setButton(int x, int y, int w, int h, int r, int g, int bl, ImageIcon ic) {
		
		JButton b = new JButton();
		b.setBounds(x, y, w, h);
		b.setBackground(new Color(r, g, bl));
		b.setIcon(ic);
		
		return b;
	}
}
