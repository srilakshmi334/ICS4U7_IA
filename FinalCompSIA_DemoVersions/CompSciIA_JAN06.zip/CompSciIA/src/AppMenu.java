// Import the following packages:
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * The following class is for the main menu of the application
 * @author Sri
 *
 */
public class AppMenu {

	static JFrame f = ChemApp.frame;
	public static ChemApp button = new ChemApp();
	public static ChemApp label = new ChemApp();

	// For displayMenu()
	static JButton student = new JButton("");
	static JButton teacher = new JButton("");

	// For displaySignUp()
//	static JTextField userInput = new JTextField();
//	static JTextField pwdInput = new JTextField();
//	static JLabel infoStatus = new JLabel("");

	// For displayLogin()
//	static HashMap<String, String> info = new HashMap<String, String>(); // stores login info
//	static String readLine;
//	static String accntFile = "accounts.txt";
//
//	static String user;
//	static String pwd;
//	static JTextField userInfo = new JTextField();
//	static JTextField pwdInfo = new JTextField();
	
	static Student s = new Student(User.user, User.pwd);
	static Teacher t = new Teacher(User.user, User.pwd);

	public static void displayMenu() {

		// Set background of frame
		f.getContentPane().setBackground(new Color(119, 158, 186));

		// Create login header/sub-header
		label.addLabel("sign-up", 280, 30, 120, 45, Font.BOLD, 35, 255, 255, 255, f);
		label.addLabel("select the appropriate profile", 210, 90, 350, 30, Font.PLAIN, 20, 245, 240, 228, f);

		// Create student and teacher JButtons/JLabels
		// JButton student = new JButton("");
		student.setIcon(new ImageIcon("student.jpg"));
		student.setBounds(170, 160, 130, 150);
		student.setBackground(new Color(186, 210, 232));

		student.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// Clear and repaint the frame
				f.getContentPane().removeAll();
				f.repaint();

				// Link to sign-up method in User class
				s.displaySignUpPage();
//				displaySignUp();
			}

		});

		label.addLabel("STUDENT", 187, 330, 120, 25, Font.PLAIN, 20, 245, 240, 228, f);

//		JButton teacher = new JButton();
		teacher.setIcon(new ImageIcon("teacher.jpg"));
		teacher.setBounds(340, 160, 180, 150);
		teacher.setBackground(new Color(186, 210, 232));

		teacher.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// Clear and repaint the frame
				f.getContentPane().removeAll();
				f.repaint();

				// Link to sign-up method in User class
//				displaySignUp();
				t.displaySignUpPage();
			}

		});

		label.addLabel("EDUCATOR", 375, 330, 120, 25, Font.PLAIN, 20, 245, 240, 228, f);

		f.add(student);
		f.add(teacher);

		// Create login question/button
		label.addLabel("already have an account?", 170, 400, 250, 30, Font.PLAIN, 20, 245, 240, 228, f);
		button.addButton("login", 410, 393, 110, 42, 25, f);

		// Create back button
		button.addButton("back", 580, 455, 80, 35, 20, f);
	}

//	/**
//	 * The following method allows the user to enter their sign-up info
//	 */
//	public static void displaySignUp() {
//
//		// Set background of frame
//		f.getContentPane().setBackground(new Color(119, 158, 186));
//
//		// Create sign-up page header
//		label.addLabel("sign-up", 280, 30, 120, 45, Font.BOLD, 35, 255, 255, 255, f);
//		label.addLabel("create your account here!", 235, 90, 330, 30, Font.PLAIN, 20, 245, 240, 228, f);
//
//		// Create JLabels/JFields for user to enter info
//		label.addLabel("username", 180, 160, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
//		label.addLabel("password", 180, 210, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
//		label.addLabel("min 8 characters", 180, 240, 180, 20, Font.PLAIN, 14, 51, 55, 138, f);
//
//		userInput.setBounds(290, 165, 200, 20);
//		userInput.setFont(new Font("Ink Free", Font.PLAIN, 15));
//
//		pwdInput.setBounds(290, 215, 200, 20);
//		pwdInput.setFont(new Font("Ink Free", Font.PLAIN, 15));
//
//		f.add(userInput);
//		f.add(pwdInput);
//
//		// Customize sign-up button
//		JButton signup = new JButton("complete sign-up");
//		signup.setBounds(225, 290, 230, 40);
//		signup.setFont(new Font("Ink Free", Font.BOLD, 25));
//		signup.setForeground(new Color(44, 79, 110));
//		signup.setBackground(new Color(186, 210, 232));
//
//		signup.addActionListener(new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				// TODO Auto-generated method stub
//
//				// Get username and password
//				String userField = userInput.getText();
//				String pwdField = pwdInput.getText();
//
//				// Repaint the JFrame and add a JLabel on the button click
//				f.getContentPane();
//				f.repaint();
//
//				// Validate the user's info
//
//				if (userField.length() < 1 || pwdField.length() < 8) {
//
//					// Inform the user that their information is incorrect
//					infoStatus.setText("seems like your info is incorrect, try again!");
//					infoStatus.setBounds(160, 350, 420, 40);
//					infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
//					infoStatus.setForeground(new Color(245, 240, 228));
//
//					f.add(infoStatus);
//				}
//
//				else {
//
//					// If correct, put info in the hash map
//					info.put(userField, pwdField);
//
//
//					//	if (e.getSource() == student) {
//
//					// Add info to a text file
//					try {
//
//						// Try writing user's info into the text file
//						BufferedWriter bw = new BufferedWriter(new FileWriter(accntFile, true));
//						bw.write(userField + " " + pwdField + "\n");
//
//						bw.close(); // close the writer after info is added
//
//						// Inform the user that they can now login
//						infoStatus.setText("you're ready to sign-up!");
//						infoStatus.setBounds(160, 370, 200, 40);
//						infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
//						infoStatus.setForeground(new Color(245, 240, 228));
//
//						f.add(infoStatus);
//
//						// Direct user to login
//						JButton reLogin = new JButton("login here");
//						reLogin.setBounds(380, 370, 150, 40);
//						reLogin.setFont(new Font("Ink Free", Font.BOLD, 25));
//						reLogin.setForeground(new Color(44, 79, 110));
//						reLogin.setBackground(new Color(213, 218, 237));
//
//						reLogin.addActionListener(new ActionListener() {
//
//							@Override
//							public void actionPerformed(ActionEvent e) {
//								// TODO Auto-generated method stub
//
//								// Clear and repaint the frame
//								f.getContentPane().removeAll();
//								f.repaint();
//
//								// Link to the login page
//								displayLogin();
//							}
//
//						});
//
//						// Add re-login button to frame
//						f.add(reLogin);
//
//					}
//
//					// Else, catch the exception
//					catch(IOException iox) {
//						System.out.println("Problem writing " + accntFile);
//					}
//				}
//
//			}
//
//		});
//
//		// Add sign-up button to frame
//		f.add(signup);
//
//		// Create back to sign-up button
//		button.addButton("back to sign-up menu", 440, 455, 230, 35, 20, f);
//
//	}

//	/**
//	 * The following method is for the user to login to the application
//	 */
//	public static void displayLogin() {
//
//		// Set background of frame
//		f.getContentPane().setBackground(new Color(119, 158, 186));
//
//		// Create login header/sub-header
//		label.addLabel("login", 300, 30, 120, 45, Font.BOLD, 35, 255, 255, 255, f);
//		label.addLabel("enter the appropriate info", 220, 90, 330, 30, Font.PLAIN, 20, 245, 240, 228, f);
//
//		// Create JLabels/JFields for user to enter info
//		label.addLabel("username", 180, 160, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
//		label.addLabel("password", 180, 210, 110, 30, Font.PLAIN, 20, 51, 55, 138, f);
//
//		userInfo.setBounds(290, 165, 200, 20);
//		userInfo.setFont(new Font("Ink Free", Font.PLAIN, 15));
//		f.add(userInfo);
//
//		pwdInfo.setBounds(290, 215, 200, 20);
//		pwdInfo.setFont(new Font("Ink Free", Font.PLAIN, 15));
//		f.add(pwdInfo);
//
//		// Create enter button
//		JButton enter = new JButton("enter");
//		enter.setBounds(280, 270, 110, 40);
//		enter.setFont(new Font("Ink Free", Font.BOLD, 25));
//		enter.setForeground(new Color(44, 79, 110));
//		enter.setBackground(new Color(186, 210, 232));
//
//		f.add(enter);
//
//		// Create back to sign-up button
//		button.addButton("back to sign-up menu", 440, 455, 230, 35, 20, f);
//
//		// Store login information
//		info = new HashMap<>();
//
//		// Try reading the accounts file and adding the info to the hash map
//		try {
//			BufferedReader read = new BufferedReader(new FileReader(accntFile));
//			String username = "";
//			String password = "";
//			String[] accountInfo;
//
//			while ((readLine = read.readLine()) != null) {
//				accountInfo = readLine.split(" "); // split the info in the array w/ a space
//
//				// Store username and password info in the array
//				username = accountInfo[0];
//				password = accountInfo[1];
//
//				// Add account information to hash map
//				info.put(username, password);
//			}
//
//		}
//
//		// If the file doesn't exist, catch the exception and print an error message
//		catch (IOException iox) {
//			System.out.println("Problem reading " + accntFile);
//		}
//
//
//		// Create an ActionListener for when the user hits the enter button to login
//		enter.addActionListener(new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				// TODO Auto-generated method stub
//
//				// Inform user of their login status
//				infoStatus.setBounds(180, 320, 400, 40);
//				infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
//				infoStatus.setForeground(new Color(245, 240, 228));
//
//				// When the user hits enter, get the text in the username and password fields
//				if (e.getSource() == enter) {
//					user = userInfo.getText();
//					pwd = pwdInfo.getText();
//
//
//					// If the user has entered the correct username and password,
//					// direct them to their profile
//					if (info.containsKey(user)) {
//						if (info.get(user).equals(pwd)) {
//
//							// Clear and re-colour the frame
//							f.getContentPane().removeAll();
//							f.setBackground(new Color(119, 158, 186));
//
//							// Link to user's profile page
////							Student s = new Student(user, pwd);
//							s.displayPlannerPage();
//
//						}
//
//						// If the user has the correct username but wrong password,
//						// display an error message saying the password is wrong
//						else {
//							infoStatus.setBounds(220, 320, 400, 40);
//							infoStatus.setText("wrong password, try again!");
//							f.add(infoStatus);
//							userInfo.setText("");
//							pwdInfo.setText("");
//
//							f.repaint();
//						}
//					}
//
//					// If the user does not have any correct info, display an error message
//					// saying that the account does not exist
//					else {
//						infoStatus.setText("this account doesn't exist, try again!");
//						f.add(infoStatus);
//						userInfo.setText("");
//						pwdInfo.setText("");
//
//						f.repaint();
//					}	
//
//				}
//
//			}
//
//		});
//	}
}
