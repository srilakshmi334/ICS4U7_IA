// Import the following packages:
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * The following sub-class is for the student profile
 * @author Sri
 *
 */
public class Student extends User {

	//	static JTextField sNum = new JTextField();

	final private static String SL = "SL";
	final private static String HL = "HL";

	static JRadioButton sl = new JRadioButton("SL");
	static JRadioButton hl = new JRadioButton("HL");

	static JLabel fileStatus = new JLabel("");

	public static JFrame IAframe = new JFrame("IA planner");
	static JButton createIA = new JButton("create IA");
	static JButton save = new JButton("save");
	static JButton saveInfo = new JButton("save info");
	static boolean saveInfoPress = false;

	//	static String nameOfUser = User.userInfo.getText();
	//	static String IAfile = userInfo.getText() + "IA_info";
	static String IAfile;
	static String sUserName;
	static JButton addHere = new JButton("add here");
	public static JFrame inventory = new JFrame("inventory list");

	static JPanel a = new JPanel();
	static FileWriter fw;
	static JScrollPane expInfo = new JScrollPane();
	static JButton sort = new JButton("sort: A-Z");
	static boolean sortPress = false;
	static JRadioButton sortR = new JRadioButton("sort: A-Z");
	
//	static JPanel jp;
//	static JScrollPane matList;

	public Student(String username, String pwd) {
		super(username, pwd);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void displayPlannerPage() {
		// TODO Auto-generated method stub

		infoStatus.setText("");
		f.remove(infoStatus);
		
		// Add header and user info
		printUserInfo();
		
		if (User.typeOfUser.equalsIgnoreCase("s") || User.typeOfUser.equalsIgnoreCase("student") || 
				AppMenu.sPress == true) {
		// Allow students to check if they're SL or HL
		label.addLabel("select level: ", 20, 230, 200, 30, Font.PLAIN, 22, 51, 55, 138, f);

		// Select only one radio button at a time
		ButtonGroup level = new ButtonGroup();

		// Customize radio buttons
		sl.setBounds(145, 235, 55, 25);
		sl.setFont(new Font("Ink Free", Font.PLAIN, 18));
		sl.setBackground(null);
		sl.setForeground(new Color(245, 240, 228));

		hl.setBounds(205, 235, 55, 25);
		hl.setFont(new Font("Ink Free", Font.PLAIN, 18));
		hl.setBackground(null);
		hl.setForeground(new Color(245, 240, 228));

		// Add the radio buttons to the button group and the frame
		level.add(sl);
		level.add(hl);
		f.add(sl);
		f.add(hl);

		// Add header for files
		label.addLabel("your files:", 20, 300, 200, 30, Font.PLAIN, 22, 51, 55, 138, f);

		// Add current file status (user has no files)
		fileStatus.setBounds(20, 340, 500, 25);
		fileStatus.setFont(new Font("Ink Free", Font.PLAIN, 18));
		fileStatus.setForeground(new Color(245, 240, 228));

		fileStatus.setText("looks like you don't have any files right now, create your IA here");
		f.add(fileStatus);

		// Add button to create IA
		createIA.setBounds(250, 390, 150, 50);
		createIA.setFont(new Font("Ink Free", Font.BOLD, 23));
		createIA.setForeground(new Color(44, 79, 110));
		createIA.setBackground(new Color(218, 235, 209));

		f.add(createIA);
		//		button.addButton("create IA", 250, 390, 150, 50, 20, f);

		createIA.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// Pop-up new frame
				expOutline();
			}

		});


		sUserName = userInfo.getText(); // get student's username

		// Add a save button
		save.setBounds(570, 450, 80, 40);
		save.setFont(new Font("Ink Free", Font.BOLD, 20));
		save.setForeground(new Color(44, 79, 110));
		save.setBackground(new Color(225, 218, 237));

		f.add(save);

		save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				//				savePress = true;

				String sNumber = sNum.getText(); // get student number
				String sEmail = uEmail.getText(); // get student's email

				// Set the standard info fields to be non-editable
				sNum.setEditable(false);
				uEmail.setEditable(false);
				sl.setEnabled(false);
				hl.setEnabled(false);

				IAfile = sUserName + "IAinfo.txt";

				try {
					//					BufferedWriter IAinfo = new BufferedWriter(new FileWriter(IAfile, true));
					//					IAinfo.write(nameOfUser + "\n");
					//					
					//					IAinfo.close();

					// Add student's info to a text file
					//					FileWriter fw = new FileWriter(IAfile, false);
					fw = new FileWriter(IAfile, true);
					fw.write("Student: " + sUserName + "\n");
					fw.write("Student #: " + sNumber + "\n");
					fw.write("Email: " + sEmail + "\n");
					if (sl.isSelected()) {
						fw.write("Level: SL" + "\n");
					}
					else if (hl.isSelected()) {
						fw.write("Level: HL" + "\n");
					}
					else {
						fw.write("Level: N/A" + "\n");
					}
					//					fw.write("Topic: " + m.getText());

					fw.close();
				}
				catch(IOException iox) {
					System.out.println("Problem writing " + IAfile);
				}

			}

		});
		}
	}

	public static void expOutline() {

		// Display the components on the JFrame
		IAframe.setLayout(null);
		IAframe.setVisible(true);
		IAframe.setResizable(false);
		//		IAframe.setLocationRelativeTo(null);
		IAframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// Set current design of JFrame
		IAframe.setSize(700, 550);
		IAframe.getContentPane().setBackground(new Color(245, 240, 228));

		// new save button
		saveInfo.setBounds(530, 450, 120, 40);
		saveInfo.setFont(new Font("Ink Free", Font.BOLD, 20));
		saveInfo.setForeground(new Color(44, 79, 110));
		saveInfo.setBackground(new Color(225, 218, 237));

		IAframe.add(saveInfo);

		IAfile = sUserName + "IAinfo.txt"; // initialize the text file w/ IA info

		saveInfo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				saveInfoPress = true; // check if save info button is pressed (to get field text)

				try {
					//					BufferedWriter IAinfo = new BufferedWriter(new FileWriter(IAfile, true));
					//					IAinfo.write(nameOfUser + "\n");
					//					
					//					IAinfo.close();

					// Add student's info to a text file
					FileWriter fw = new FileWriter(IAfile, true);
					fw = new FileWriter(IAfile, true);
					//					JScrollPane expInfo = new JScrollPane();
					//					field.addTextField(expInfo, 80, 125, 360, 40, "Topic: ");

					// Call method to get ia text from the fields
					// **error, currently only points to one field when method is called
					// try changing method to call next field in a loop? or try enable field to false
					getField.addTextField("Topic: ", "sTopic");
					getField.addTextField("Research Question: ", "sQstn");
					getField.addTextField("Hypothesis: ", "sHyp");
					getField.addTextField("Procedure: ", "sPro");
					
//					JTextField sTopic = new JTextField();
//					field.addTextField(sTopic, expInfo, 80, 125, 360, 40, "Topic: ");

				}
				catch(IOException iox) {
					System.out.println("Problem writing " + IAfile);
				}
			}

		});

		// Create a header for the experiment page
		label.addLabel("the IA", 270, 50, 200, 45, Font.BOLD, 35, 44, 79, 110, IAframe);


		// ***************************TESTING***************************
		//		JPanel a = new JPanel();
		//		a.setFont(new Font("Ink Free", Font.BOLD, 28));

		//		JScrollPane sp2 = new JScrollPane(a, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		//		sp2.setBounds(80, 80, 600, 400);
		//		IAframe.add(sp2);
		//		
		//		
		////		JScrollPane a = new JScrollPane();
		//		label.addLabel("topic:", 20, 130, 150, 30, a, IAframe);

		// either use jscrollpane or make frame longer or for procedure section add scrollpane

		// Add labels and text fields for other experiment info
		label.addLabel("topic:", 20, 130, 150, 30, Font.PLAIN, 22, 51, 55, 138, IAframe);
		label.addLabel("research question:", 20, 180, 270, 30, Font.PLAIN, 22, 51, 55, 138, IAframe);
		label.addLabel("hypothesis:", 20, 230, 220, 30, Font.PLAIN, 22, 51, 55, 138, IAframe);
		label.addLabel("materials:", 20, 280, 220, 30, Font.PLAIN, 22, 51, 55, 138, IAframe);
		label.addLabel("procedure:", 20, 330, 220, 30, Font.PLAIN, 22, 51, 55, 138, IAframe);

		//		expInfo = new JScrollPane();
		field.addTextField(expInfo, 80, 125, 360, 40, IAframe); // for topic
		field.addTextField(expInfo, 200, 175, 360, 40, IAframe); // for research question
		field.addTextField(expInfo, 140, 225, 360, 40, IAframe); // for hypothesis
		field.addTextField(expInfo, 130, 325, 360, 40, IAframe); // for procedure

		// Add button to open inventory list
		addHere.setBounds(130, 275, 120, 40);
		addHere.setFont(new Font("Ink Free", Font.BOLD, 20));
		addHere.setForeground(new Color(255, 255, 255));
		addHere.setBackground(new Color(167, 178, 194));
		IAframe.add(addHere);

		//		IAframe.add(sp2);

		addHere.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// Display the components on the JFrame
				inventory.setLayout(null);
				inventory.setVisible(true);
				inventory.setResizable(false);
				inventory.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

				// Set current design of JFrame
				inventory.setSize(300, 350);
				inventory.getContentPane().setBackground(new Color(167, 178, 194));

				// Create JPanel for the inventory list
				JPanel jp = new JPanel();
				jp.setBackground(new Color(167, 178, 194));
				jp.setBorder(null);
				jp.setLayout(new BoxLayout(jp, BoxLayout.PAGE_AXIS)); // used to left-vertical align checkboxes to panel

				// Add a JScrollPane to the JPanel
				JScrollPane matList = new JScrollPane(jp, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				matList.setBounds(0, 0, 285, 315);
				inventory.add(matList);

				// Add inventory sort button
				
				JButton sort = new JButton("sort: A-Z");
				sort.setBounds(0, 10, 30, 25);
				sort.setFont(new Font("Ink Free", Font.PLAIN, 14));
				sort.setBackground(new Color(250, 242, 232));
				jp.add(sort);

				// Create JCheckBoxes for materials
				// Create field for user to write chemicals

				// Initialize variables
				String f = "inventory.txt";
				String ln;
				ArrayList<String> tools = new ArrayList<String>();
				ArrayList<String> sTools = new ArrayList<String>();

				// Read in the lines from the text file and add it to the array list
				try {
					BufferedReader r = new BufferedReader(new FileReader(f));
					while ((ln = r.readLine()) != null) {
						tools.add(ln);
					}
				}
				catch(IOException iox) {
					System.out.println("Problem reading " + f);
				}

				// Loop through the array list and display the checkboxes on the frame
				for (int i = 0; i < tools.size(); i++) {
					chkBox.addCheckBox(tools.get(i), 0, 0, 0, 0, jp);
					
					// RUN INTO THE SAME PROBLEM AS THE FIELDS - (MULTIPLE CHECKBOXES ONLY POINTS
					// TO ONE AT A TIME)
				}
				
//				if (sortPress == false) {
//					for (int i = 0; i < tools.size(); i++) {
//						chkBox.addCheckBox(tools.get(i), 0, 0, 0, 0, jp);
//					}
//				}


				sort.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						
						sortPress = true;
						
						if (sortPress == true) {
							Collections.sort(tools);
							for (int i = 0; i < tools.size(); i++) {
								sTools.add(i, tools.get(i));
//								System.out.println(sTools.get(i));
							}
							
							inventory.getContentPane().removeAll();
							jp.repaint();
							jp.revalidate();
							matList.repaint();
							matList.revalidate();
							
							JPanel jpl = new JPanel();
							jpl.setBackground(new Color(167, 178, 194));
							jpl.setBorder(null);
							jpl.setLayout(new BoxLayout(jpl, BoxLayout.PAGE_AXIS));
							
							JScrollPane smatList = new JScrollPane(jpl, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
							smatList.setBounds(0, 0, 285, 315);
							inventory.add(smatList);
							
							for (int j = 0; j < sTools.size(); j++) {
								chkBox.addCheckBox(sTools.get(j), 0, 0, 0, 0, jpl);
							}
							
//							inventory.add(matList);
//							jp.add(sort);
//							for (int j = 0; j < tools.size(); j++) {
//								chkBox.addCheckBox(tools.get(j), 20, 50, 100, 20, jp);
//							}
						}

					}

				});
			}

		});
	}

	@Override
	public void displaySignUpPage() {
		// TODO Auto-generated method stub	
		displaySignUp();

		signup.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// Get username and password
				String userField = userInput.getText();
				String pwdField = pwdInput.getText();

				// Repaint the JFrame and add a JLabel on the button click
				f.getContentPane();
				f.repaint();

				// Validate the user's info

				if (userField.length() < 1 || pwdField.length() < 8) {

					// Inform the user that their information is incorrect
					infoStatus.setText("seems like your info is incorrect, try again!");
					infoStatus.setBounds(160, 350, 420, 40);
					infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
					infoStatus.setForeground(new Color(245, 240, 228));

					f.add(infoStatus);
				}

				else {

					// If correct, put info in the hash map
					info.put(userField, pwdField);
					//					generateStudentID();

					//	if (e.getSource() == student) {

					// Add info to a text file
					try {

						// Try writing user's info into the text file
						BufferedWriter bw = new BufferedWriter(new FileWriter(accntFile, true));
						bw.write(userField + " " + pwdField + "\n");

						bw.close(); // close the writer after info is added

						// Inform the user that they can now login
						infoStatus.setText("you're ready to sign-up!");
						infoStatus.setBounds(160, 370, 200, 40);
						infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
						infoStatus.setForeground(new Color(245, 240, 228));

						f.add(infoStatus);

						// Direct user to login
						JButton reLogin = new JButton("login here");
						reLogin.setBounds(380, 370, 150, 40);
						reLogin.setFont(new Font("Ink Free", Font.BOLD, 25));
						reLogin.setForeground(new Color(44, 79, 110));
						reLogin.setBackground(new Color(213, 218, 237));

						reLogin.addActionListener(new ActionListener() {

							@Override
							public void actionPerformed(ActionEvent e) {
								// TODO Auto-generated method stub

								// Clear and repaint the frame
								f.getContentPane().removeAll();
								f.repaint();

								// Link to the login page
								s.displayLoginPage();
							}

						});

						// Add re-login button to frame
						f.add(reLogin);

					}

					// Else, catch the exception
					catch(IOException iox) {
						System.out.println("Problem writing " + accntFile);
					}
				}

			}

		});

		//		// Add sign-up button to frame
		//		f.add(signup);
		//
		//		// Create back to sign-up button
		//		button.addButton("back to sign-up menu", 440, 455, 230, 35, 20, f);
	}

	@Override
	public void displayLoginPage() {
		// TODO Auto-generated method stub
		displayLogin();

		// Try reading the accounts file and adding the info to the hash map
		try {
			BufferedReader read = new BufferedReader(new FileReader(accntFile));
			String username = "";
			String password = "";
			String[] accountInfo;

			while ((readLine = read.readLine()) != null) {
				accountInfo = readLine.split(" "); // split the info in the array w/ a space

				// Store username and password info in the array
				username = accountInfo[0];
				password = accountInfo[1];

				// Add account information to hash map
				info.put(username, password);

			}

		}

		// If the file doesn't exist, catch the exception and print an error message
		catch (IOException iox) {
			System.out.println("Problem reading " + accntFile);
		}


		// Create an ActionListener for when the user hits the enter button to login
		enter.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// Inform user of their login status
				infoStatus.setBounds(180, 320, 400, 40);
				infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
				infoStatus.setForeground(new Color(245, 240, 228));

				// When the user hits enter, get the text in the username and password fields
				if (e.getSource() == enter) {
					//					typeOfUser = userType.getText();
					infoStatus.setText("");
					user = userInfo.getText();
					pwd = pwdInfo.getText();

					// If the user has entered the correct username and password,
					// direct them to their profile
					//					if (typeOfUser.equals("s")) {
					if (info.containsKey(user)) {
						if (info.get(user).equals(pwd)) {

							// Clear and re-colour the frame
							f.getContentPane().removeAll();
							f.setBackground(new Color(119, 158, 186));

							// Link to user's profile page
							// Student s = new Student(user, pwd);
							//							printUserInfo();
							s.displayPlannerPage();
							enterSPlannerPage = true; // check if the student enters planner page

						}

						// If the user has the correct username but wrong password,
						// display an error message saying the password is wrong
						else {
							infoStatus.setBounds(220, 320, 400, 40);
							infoStatus.setText("wrong password, try again!");
							f.add(infoStatus);
							userInfo.setText("");
							pwdInfo.setText("");

							f.repaint();
						}
					}
					//				}

					// If the user does not have any correct info, display an error message
					// saying that the account does not exist
					else {
						infoStatus.setText("this account doesn't exist, try again!");
						f.add(infoStatus);
						userInfo.setText("");
						pwdInfo.setText("");

						f.repaint();
						f.revalidate();
					}

					userInfo.setText("");
					pwdInfo.setText("");

				}

			}

		});
	}

}
