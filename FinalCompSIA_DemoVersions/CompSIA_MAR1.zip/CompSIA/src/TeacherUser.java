
public class TeacherUser extends GeneralUser {

	public TeacherUser(String username, String password) {
		super(username, password);
		// TODO Auto-generated constructor stub
	}

}
