// Import the following packages:
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class MaterialsPanel extends JPanel {
	
	private JPanel jp;
	private JLabel inventoryH;
	private String inventoryFile = "./inventory.txt", line;
	private ArrayList<String> tools = new ArrayList<String>();
	private ArrayList<JCheckBox> cb = new ArrayList<JCheckBox>();
	private JCheckBox materials;
	private JButton backToIABtn, saveInvBtn;
	
	public MaterialsPanel() {
		
		this.setLayout(null);
//		this.setSize(300, 350);
		this.setBackground(new Color(119, 158, 186));
		
		inventoryH = GUIComp.setLabel("inventory", 270, 30, 240, 45, Font.BOLD, 35, 255, 255, 255);
		this.add(inventoryH);
		
		jp = new JPanel();
		JScrollPane matList = new JScrollPane(jp, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jp.setBackground(new Color(119, 158, 186));
		jp.setLayout(new BoxLayout(jp, BoxLayout.PAGE_AXIS));
		matList.setBounds(20, 80, 650, 350);
		matList.setBorder(null);
		this.add(matList);
		
		StudentPlannerPanel.IAFileInfo = "./" + TeacherPlannerPanel.userNm + "IAinfo.txt"; // initialize the text file w/ IA info
		
		// Read in the lines from the text file and add it to the array list
		try {
			BufferedReader r = new BufferedReader(new FileReader(inventoryFile));
			while ((line = r.readLine()) != null) {
				tools.add(line);
//				System.out.println("materials " + line);
			}
		}
		catch(IOException iox) {
			System.out.println("Problem reading " + inventoryFile);
		}
		
		
		// Loop through the array list and display the checkboxes on the frame
		for (int i = 0; i < tools.size(); i++) {
			materials = new JCheckBox();
			materials = GUIComp.setCheckBox(materials, tools.get(i), 0, 0, 0, 0);
			jp.add(materials);
			cb.add(materials);
//			System.out.println(materials);
		}
		
		// Create save inventory button
		saveInvBtn = new JButton("save inventory");
		saveInvBtn.setBounds(40, 450, 170, 40);
		saveInvBtn.setFont(new Font("Ink Free", Font.BOLD, 20));
		saveInvBtn.setForeground(new Color(44, 79, 110));
		saveInvBtn.setBackground(new Color(225, 218, 237));
		this.add(saveInvBtn);
		
		saveInvBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (materials.isShowing()) {
					System.out.println(materials.getText());
//					materials.i
				}
				
//				if (materials.isSelected()) {
				try {
					FileWriter fw = new FileWriter(StudentPlannerPanel.IAFileInfo, true);
					fw.write("Materials: " + "\n");
//					if (materials.isSelected()) {
//						fw.write("- " + materials.getText());
//					}
					for (int j = 0; j < tools.size(); j++) {
						if (materials.isSelected()) {
							fw.write("- " + materials.getText());
						}
					}
					
					fw.close();
				}
				catch(IOException iox) {
					System.out.println("Problem writing " + StudentPlannerPanel.IAFileInfo);
				}
				
//				}
			}
			
		});
		
		
		// Create back to IA button
		backToIABtn = GUIComp.setButton("back to IA", 475, 450, 170, 40, 22);
		this.add(backToIABtn);
		
		backToIABtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				ChemPlanApp.cl.show(ChemPlanApp.c, "IAPage");
			}
			
		});
		
	}
}
