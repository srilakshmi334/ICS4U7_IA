// Import the following packages:
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TeacherPlannerPanel extends JPanel {
	
	private JLabel planHeader, usernameLbl, welcomeH, instructionH, stdNmLbl, stdEmlLbl, andLbl, errorLbl;
	private String chkUser, chkEmail, line;
	private JTextField stdNameField, stdEmailField;
	private JButton viewIABtn, logoutBtn;
	private BufferedReader br;
	private boolean found;
	
	static String userNm;
	 
	public TeacherPlannerPanel() {
		
		this.setLayout(null);
		this.setBackground(new Color(119, 158, 186));
		
		planHeader = GUIComp.setLabel("your planner", 240, 50, 240, 45, Font.BOLD, 35, 255, 255, 255);
		this.add(planHeader);
		
		userNm = LoginPanel.userInfo.getText();
		usernameLbl = GUIComp.setLabel("hello, " + userNm, 20, 20, 200, 30, Font.PLAIN, 20, 255, 255, 255);
		this.add(usernameLbl);
		
		welcomeH = GUIComp.setLabel("welcome, this is your page to review your students' IAs", 70, 130, 520, 30, Font.PLAIN, 22, 51, 55, 138);
		this.add(welcomeH);
		
		instructionH = GUIComp.setLabel("enter student username and email to view", 165, 180, 330, 20, Font.PLAIN, 18, 245, 240, 228);
		this.add(instructionH);
		
		// Create JLabels & JTextFields for the following info
		stdNmLbl = GUIComp.setLabel("student name:", 160, 230, 200, 30, Font.PLAIN, 20, 245, 241, 240);
		this.add(stdNmLbl);
		
		stdNameField = new JTextField();
		stdNameField.setBounds(295, 235, 200, 20);
		stdNameField.setFont(new Font("Ink Free", Font.PLAIN, 15));
		this.add(stdNameField);
		
		andLbl = GUIComp.setLabel("AND", 320, 280, 50, 30, Font.PLAIN, 21, 51, 55, 138);
		this.add(andLbl);
		
		stdEmlLbl = GUIComp.setLabel("student email:", 160, 320, 200, 30, Font.PLAIN, 20, 245, 241, 240);
		this.add(stdEmlLbl);
		
		stdEmailField = new JTextField();
		stdEmailField.setBounds(295, 325, 200, 20);
		stdEmailField.setFont(new Font("Ink Free", Font.PLAIN, 15));
		this.add(stdEmailField);
		
		// Logout JButton
		logoutBtn = GUIComp.setButton("logout", 510, 450, 140, 40, 22);
		this.add(logoutBtn);
		
		logoutBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				// Link to logout page
				ChemPlanApp.cl.show(ChemPlanApp.c, "logoutPage");
			}
			
		});
		
		// Leads to the student's IA page
		viewIABtn = new JButton("view IA");
		viewIABtn.setBounds(260, 380, 140, 45);
		viewIABtn.setFont(new Font("Ink Free", Font.BOLD, 23));
		viewIABtn.setForeground(new Color(51, 55, 138));
		viewIABtn.setBackground(new Color(200, 195, 212));
		this.add(viewIABtn);
		
		viewIABtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				chkUser = stdNameField.getText();
				chkEmail = stdEmailField.getText();
				
				StudentPlannerPanel.IAFileInfo = "./" + userNm + "IAinfo.txt";
				
				try {
					br = new BufferedReader(new FileReader(StudentPlannerPanel.IAFileInfo));
					
					while ((line = br.readLine()) != null) {
						String check = chkEmail;
						if (line.contains(check)) {
							found = true;
						}
					}
				}
				catch(IOException iox) {
					System.out.println("Problem reading " + StudentPlannerPanel.IAFileInfo);
				}
				
				if (found == true) {
					// Link to student's IA page
					ChemPlanApp.cl.show(ChemPlanApp.c, "reviewIAPage");
				}
				
				else {
					errorLbl = GUIComp.setLabel("sorry, wrong user or email, please try again", 155, 400, 400, 20, Font.PLAIN, 20, 245, 240, 228);
					add(errorLbl);
				}
			}
			
		});
		
	}
}
