// Import the following packages:
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ConfirmIDPanel extends JPanel {
	
	private JLabel confirmPageHeader, genInstruction, userTypeHeader, miniInstruction, infoStatus;
	private JTextField userType;
	private JButton confirmUser;
	private String typeOfUser;

	public ConfirmIDPanel() {
		
		this.setLayout(null);
		this.setBackground(new Color(119, 158, 186));
		
		confirmPageHeader = GUIComp.setLabel("wait, confirm your identity", 130, 30, 480, 45, Font.BOLD, 35, 255, 255, 255);
		this.add(confirmPageHeader);
		
		genInstruction = GUIComp.setLabel("enter student or teacher", 220, 90, 330, 30, Font.PLAIN, 20, 245, 240, 228);
		this.add(genInstruction);
		
		userTypeHeader = GUIComp.setLabel("user type", 180, 160, 110, 30, Font.PLAIN, 20, 51, 55, 138);
		this.add(userTypeHeader);
		
		miniInstruction = GUIComp.setLabel("type s or t", 180, 185, 110, 30, Font.PLAIN, 14, 51, 55, 138);
		this.add(miniInstruction);
		
		userType = new JTextField();
		userType.setBounds(290, 165, 200, 20);
		userType.setFont(new Font("Ink Free", Font.PLAIN, 15));
		this.add(userType);
		
		confirmUser = GUIComp.setButton("confirm", 280, 250, 110, 40, 20);
		this.add(confirmUser);
		
		infoStatus = new JLabel();
		infoStatus.setBounds(225, 320, 420, 40);
		infoStatus.setFont(new Font("Ink Free", Font.PLAIN, 20));
		infoStatus.setForeground(new Color(245, 240, 228));
		this.add(infoStatus);
		
		confirmUser.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				typeOfUser = userType.getText();
				if (typeOfUser.equalsIgnoreCase("s") || typeOfUser.equalsIgnoreCase("student")) {
					ChemPlanApp.cl.show(ChemPlanApp.c, "loginPage");
				}
				else if (typeOfUser.equalsIgnoreCase("t") || typeOfUser.equalsIgnoreCase("teacher")) {
					ChemPlanApp.cl.show(ChemPlanApp.c, "loginPage");
				}
				else {
					infoStatus.setText("oops, wrong user. try again!");
					infoStatus.setBounds(225, 320, 420, 40);
					userType.setText("");
				}
			}
			
		});
		
	}
}
